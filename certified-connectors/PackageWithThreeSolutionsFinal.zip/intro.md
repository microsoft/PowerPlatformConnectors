This connector allows you to use the main invoice functions in Tesseron. Create open position notes and activity recordings. Integrate Tesseron into your flows and automate your business processes. 

## Prerequisites

You will need the following to proceed:
* A Tesseron Instance
* A Tesseron licensed user
* An API Key (Service: Ticket)

## How to get credentials

Please request your API Key from your system partner or administrator.

## Get started with your connector

Since Tesseron Rest API uses API keys to validate your user, you first need to contact your system administrator to create an API key for your user. After that is completed you can create your Tesseron ASM connection.

1. Check user rights
With this connector you will be able to perform invoice actions within your Tesseron instance. Therefore you need to have the mandatory user rights.

2. Apply for your API key
Currently, API keys can only be created by your system administrator. Therefore, request your API key from your system administrator.

3. Create a new connection
    - Provide your Tesseron instance URL
    - Enter your Tesseron API key


## Known issues and limitations

* Sufficient user rights are mandatory

## Common errors and remedies



## FAQ

Is there any extra charge using this connector? No