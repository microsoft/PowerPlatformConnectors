Connect to your Cognite Data Fusion project using the Cognite Data Fusion API endpoints found at https://api-docs.cognite.com/

Documentation: https://docs.cognite.com/
Developer: https://developer.cognite.com/

## Prerequisites

You will need the following to proceed:
* A Cognite Data Fusion Project
* OAuth2 configured with your Cognite Data Fusion Project (see below)


## How to get credentials

Please contact your Cognite Project representative to set up your Cognite Data Fusion Project and Active Directory credentials.

## Get started with your connector

Explore the Cognite Data Fusion API endpoints found at https://api-docs.cognite.com/
Using the documentation as guide for parameters, you can use this connector to access, modify, and delete data in your Cognite Data Fusion Project.

## Known issues and limitations

This is a partial connector containing Time Series and Data Modeling endpoints to the Cognite Data Fusion API with ongoing development for all other endpoints.

## Common errors and remedies

Most syntax and typings are set for the Cognite Data Fusion Platform connector, however for the more complex parameters, please consult the Cognite Data Fusion API documentation. For additional support, please contact Cognite Support at support@cognite.com.
