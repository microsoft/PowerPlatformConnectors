# Fluxx connector for Power Automate

The Fluxx connector uses the Fluxx REST API to access a Fluxx site.

## Prerequisites

You will need the following to proceed:

- A Fluxx subscription that includes Grantmaker access
- A Fluxx site (example: myfoundation.fluxx.io)

## Configuration

When creating a connection, you will need the following:

- The domain of your Fluxx site (example: `myfoundation.fluxx.io`)
- The App ID of an OAuth application (available at `/oauth/applications` on your Fluxx site)
- The App Secret of an OAuth application (available at `/oauth/applications` on your Fluxx site)

## Supported Operations

- `Create Record` - Creates a record of the specified type on your Fluxx site.
- `Custom Action` - Makes a request to the Fluxx REST API endpoint of your choice.
- `Download Document` - Downloads a document from your Fluxx site.
- `Find or Create Record` - Searches for a record of the specified type with the given parameters. If none exists, creates the record.
- `Find Record` - Retrieves the record with the specified ID from your Fluxx site.
- `Find Record(s)` - Searches for records by the given parameters.
- `Update Record` - Updates a record with the specified ID with the given parameters.
- `Upload Document` - Uploads a document to your Fluxx site.
- `When a record is created` - Triggers when a record of the specified type is created on your Fluxx site.
- `When a record is updated` - Triggers when a record of the specified type is updated on your Fluxx site. If a tracked field is provided, only triggers when the specified field is updated for the specified record type.
