Maximizer CRM empowers businesses to streamline processes, build stronger customer relationships, and close deals faster. The Maximizer Connector for Power Automate allows you to create powerful workflows that reduce manual work and increase productivity. Automatically trigger follow-ups when new leads are added, sync data across platforms, or schedule appointments in Maximizer from Microsoft Bookings. Keep your team aligned and focused on growing customer value—without missing a beat.

## Prerequisites

You will need the following to proceed:

- Maximizer account
- Microsoft Power Apps or Power Automate plan

## How to get credentials
In order to get access to Maximizer, please visit maximizer.com and sign up.


## Known issues and limitations
-  To access the UDF values from the previous steps, please click "Add dynamic content", go to "Expression" tab and enter "item()?['UdfName']". (Replace UdfName with the name of the desired UDF.)"
 [Expression Reference](https://docs.microsoft.com/en-us/azure/logic-apps/workflow-definition-language-functions-reference)


## Common errors and remedies

- If the trigger or action fails, you can find some details about the error in the response body. Have a look at the "code" and "message" keys.

