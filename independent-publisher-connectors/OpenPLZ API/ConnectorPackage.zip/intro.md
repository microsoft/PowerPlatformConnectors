# OpenPLZ API Connector

The **OpenPLZ API Connector** provides structured access to postal codes, streets, administrative divisions, and locality data for **Germany**, **Switzerland**, **Austria**, and **Liechtenstein**. It enables Microsoft Power Platform solutions to query reliable and normalized location datasets in a REST-based format.

This connector exposes multiple read-only operations that allow retrieval of hierarchical information such as federal states, cantons, districts, municipalities, localities, postal codes, and streets.

## Publisher

[OpenPLZ API](https://www.openplzapi.org)

---

## Supported Features

The OpenPLZ API Connector supports the following capabilities:

- Retrieve administrative hierarchies (federal states, cantons, districts, municipalities, municipal associations, localities)
- Perform postal code lookups
- Query street directories
- Work with cross-country coverage (Germany, Switzerland, Austria, Liechtenstein)
- Consume consistent JSON response formats suitable for automation and validation

---

## Prerequisites

There are no prerequisites required to use this connector:

- No API key
- No OAuth
- No authentication
- No subscription

The API is publicly accessible.

---

## How to Use the Connector

1. Add the OpenPLZ API Connector to your Power App or Power Automate flow.
2. Choose one of the available actions.
3. Provide the required parameters.
4. Use the returned JSON data in your workflow or app (for example, to populate dropdown lists, validate addresses, or store structured location data).

---

## Connection Information

The connector uses a single anonymous connection. No credentials are required.

---

## Known Limitations

- Read-only API (only GET operations are available)
- Potential rate limiting for excessive or high-frequency requests
- No geocoordinates or polygon boundary data
- Administrative and locality names follow German-language naming conventions

---

## API Documentation

- [General documentation](https://www.openplzapi.org)
- [Germany documentation](https://www.openplzapi.org/de/germany/)
- [Switzerland documentation](https://www.openplzapi.org/de/switzerland/)
- [Austria documentation](https://www.openplzapi.org/de/austria/)
- Liechtenstein is included in the Switzerland documentation

---

## Recommended API Call Order per Country

The following sections describe a recommended sequence of API calls to retrieve hierarchical administrative structures in a logical order for each country.

### Germany (DE)

#### Germany – Base Data

- GET /de/FederalStates (List all federal states (Germany))

#### Germany – Federal State Level (using federalStateKey)

- GET /de/FederalStates/{federalStateKey}/GovernmentRegions (List government regions of a federal state (Germany))
- GET /de/FederalStates/{federalStateKey}/Districts (List districts of a federal state (Germany))
- GET /de/FederalStates/{federalStateKey}/Municipalities (List municipalities of a federal state (Germany))
- GET /de/FederalStates/{federalStateKey}/MunicipalAssociations (List municipal associations of a federal state (Germany))
- GET /de/FederalStates/{federalStateKey}/Localities (List localities of a federal state (Germany))

#### Germany – Government Region Level (using governmentRegionKey)

- GET /de/GovernmentRegions/{governmentRegionKey}/Districts (List districts of a government region (Germany))
- GET /de/GovernmentRegions/{governmentRegionKey}/Municipalities (List municipalities of a government region (Germany))
- GET /de/GovernmentRegions/{governmentRegionKey}/MunicipalAssociations (List municipal associations of a government region (Germany))
- GET /de/GovernmentRegions/{governmentRegionKey}/Localities (List localities of a government region (Germany))

#### Germany – District Level (using districtKey)

- GET /de/Districts/{districtKey}/Municipalities (List municipalities of a district (Germany))
- GET /de/Districts/{districtKey}/MunicipalAssociations (List municipal associations of a district (Germany))
- GET /de/Districts/{districtKey}/Localities (List localities of a district (Germany))

#### Germany – Search Endpoints

- GET /de/Localities (Search localities and postal codes (Germany))
- GET /de/Streets (Search streets (Germany))
- GET /de/FullTextSearch (Full-text search for streets, postal codes and localities (Germany))

---

### Liechtenstein (LI)

#### Liechtenstein – Base Data

- GET /li/Communes (List all communes (Liechtenstein))

#### Liechtenstein – Search Endpoints

- GET /li/Localities (Search localities and postal codes (Liechtenstein))
- GET /li/Streets (Search streets (Liechtenstein))
- GET /li/FullTextSearch (Full-text search for streets (Liechtenstein))

---

### Switzerland (CH)

#### Switzerland – Base Data

- GET /ch/Cantons (List all cantons (Switzerland))

#### Switzerland – Canton Level (using cantonKey)

- GET /ch/Cantons/{cantonKey}/Districts (List districts of a canton (Switzerland))
- GET /ch/Cantons/{cantonKey}/Communes (List communes of a canton (Switzerland))
- GET /ch/Cantons/{cantonKey}/Localities (List localities of a canton (Switzerland))

#### Switzerland – District Level (using districtKey)

- GET /ch/Districts/{districtKey}/Communes (List communes of a district (Switzerland))
- GET /ch/Districts/{districtKey}/Localities (List localities of a district (Switzerland))

#### Switzerland – Search Endpoints

- GET /ch/Localities (Search localities and postal codes (Switzerland))
- GET /ch/Streets (Search streets (Switzerland))
- GET /ch/FullTextSearch (Full-text search for streets (Switzerland))

---

### Austria (AT)

#### Austria – Base Data

- GET /at/FederalProvinces (List all federal provinces (Austria))

#### Austria – Federal Province Level (using federalProvinceKey)

- GET /at/FederalProvinces/{federalProvinceKey}/Districts (List districts of a federal province (Austria))
- GET /at/FederalProvinces/{federalProvinceKey}/Municipalities (List municipalities of a federal province (Austria))
- GET /at/FederalProvinces/{federalProvinceKey}/Localities (List localities of a federal province (Austria))

#### Austria – District Level (using districtKey)

- GET /at/Districts/{districtKey}/Municipalities (List municipalities of a district (Austria))
- GET /at/Districts/{districtKey}/Localities (List localities of a district (Austria))

#### Austria – Search Endpoints

- GET /at/Localities (Search localities and postal codes (Austria))
- GET /at/Streets (Search streets (Austria))
- GET /at/FullTextSearch (Full-text search for streets (Austria))
