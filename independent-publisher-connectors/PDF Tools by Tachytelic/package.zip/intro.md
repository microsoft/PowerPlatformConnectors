# Composer Power Platform Connector

**Composer** is a productivity connector for Microsoft Power Platform, designed to simplify complex tasks in your flows. It offers high-performance utilities for text, data, file, and API operations — all from a single connector.

## Prerequisites

To use this connector, you must obtain an API key from [https://composer.tachytelic.net](https://composer.tachytelic.net).

> 💡 The **Starter** plan is free and allows 100 actions/month. Paid tiers increase limits and remove throttling.

## Get an API Key

Visit [https://composer.tachytelic.net](https://composer.tachytelic.net) and sign up for an API key. Your API key must be supplied with every request.

---

## Supported Operations

### 🧠 String Operations
- **CleanText**: Removes unwanted characters, trims text, strips control codes.
- **ExtractEmails**: Extracts all email addresses from a string.
- **ExtractText**: Gets text between two specified strings (optionally include bounds).
- **ExtractMultipleTexts**: Finds all occurrences of text between two strings.
- **HashString**: Computes a hash (SHA256, MD5, etc.) of a given input string.

### 📅 Date Utilities
- **CalculateNextWorkingDay**: Calculates the next working day, skipping weekends/holidays.
- **GenerateWorkingDays**: Produces a list of upcoming working days based on a start date.

### 📁 File Operations

#### CSV
- **ParseCsv**: Parses a CSV file into structured JSON with optional headers and delimiter support.

#### Archives (ZIP, 7z, RAR, TAR, etc.)
- **ZipContent**: Creates a zip archive from one or more base64-encoded files (supports password protection).
- **ExtractArchive**: Extracts all files from an archive (auto-detects format).
- **ListArchiveContent**: Lists filenames and metadata from an archive without extracting.
- **ExtractFileFromArchive**: Extracts a single file by name from an archive.

#### PDF
- **ExtractTextFromPdf**: Extracts plain text from all or selected pages in a PDF.
- **GetPdfInfo**: Retrieves metadata (title, author, page count, version) from a PDF.
- **SetPdfMetadata**: Updates metadata properties (title, author, etc.) of a PDF file.
- **MergePdfs**: Combines multiple PDFs into a single file.
- **SplitPdf**: Splits a PDF by number of pages or by specified page ranges.
- **ExtractPdfPages**: Extracts specific pages from a PDF file into a new PDF.

#### Word
- **ExtractTextFromWord**: Extracts text from a DOCX Word document.
- **ExtractCommentsFromWord**: Extracts review comments from a DOCX Word document.

### 🔢 Array Utilities
- **MergeArrays**: Joins two arrays based on a common property using different strategies.
- **AggregateArray**: Calculates sum, average, min, max, or count from a list of numbers or objects.

### 🔍 Regex Tools
- **RegexMatch**: Finds regex matches in a string and returns match data and groups.
- **RegexMatchBatch**: Applies multiple regex patterns to a single input string and returns named results.
- **RegexReplace**: Performs a regex search and replace on input text.

### 🖼 Image Processing
- **ResizeImage**: Resizes an image to a specified width/height (with optional aspect ratio).
- **CompressImage**: Compresses an image to reduce size (JPEG/PNG).
- **FlipImage**: Flips an image horizontally or vertically.
- **RotateImage**: Rotates an image by a specified angle.

### 💼 SharePoint
- **BatchCreateSharePointItems**: Generates an OData batch request to create multiple SharePoint list items.
- **BatchDeleteSharePointItems**: Generates a batch request to delete SharePoint items by ID.
- **BatchUpdateSharePointItems**: Generates a batch request to update existing SharePoint list items.

### 🧬 Dataverse
- **BatchCreateDataverseRecords**: Builds batch requests to create new rows in a Dataverse table.
- **BatchDeleteDataverseRecordsSimple**: Creates batch requests to delete records using `@odata.id` values.
- **BatchDeleteDataverseRecordsAdvanced**: Builds delete batches using GUIDs and table schema details.

### ⚙️ Miscellaneous
- **JsonPath**: Evaluates a JSONPath expression and returns the matched values.
- **XsltTransform**: Applies an XSLT transformation to input XML.
- **ExtractFormAttachments**: Extracts file metadata from Microsoft Forms attachments stored as JSON strings.

---

## Support

If you have any questions or issues, visit [https://composer.tachytelic.net/support/](https://composer.tachytelic.net/support/) or email composerhelp@tachytelic.net.
