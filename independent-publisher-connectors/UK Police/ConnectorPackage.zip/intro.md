# Police UK (Independent Publisher)

The UK Police connector provides access to official crime, stop and search, neighbourhood, and police force data across England, Wales, and Northern Ireland. Data is sourced directly from the official UK Police public API at [data.police.uk](https://data.police.uk), maintained by the Home Office. No credentials or registration are required to use this connector.

## Publisher: Josh Bray

## Prerequisites

No prerequisites are required. The UK Police API is free, publicly accessible, and does not require an account, API key, or any form of registration.

## Supported Operations

### `Get specific force`
Returns detailed information for a specified police force, including name, description, website URL, telephone number, and available engagement methods such as social media and contact forms.

### `Get last updated date`
Returns the date that the crime data was last updated. Use this action to check whether new data has been published before making subsequent requests, or to display data freshness information to end users.

### `Get specific neighbourhood`
Returns details for a specific neighbourhood within a police force, including name, description, centre coordinates, contact details, and associated locations such as police stations.

### `Get neighbourhood team`
Returns the policing team members assigned to a specific neighbourhood, including their name, rank, and contact details where available.

### `Get force senior officers`
Returns a list of senior officers for a specified police force, including their name, rank, and biography where available.

### `Get stop and searches by force`
Returns all stop and search records carried out by a specified police force for a given month. Results include the outcome, object of search, legislation used, and where available the age range, gender, and ethnicity of the person searched. If no date is provided, the latest available month is used.

### `List crime categories`
Returns a list of valid crime category slugs for a given month. Use the returned values as the category parameter in the Get street-level crimes action. If no date is provided, the latest available month is used.

### `List all forces`
Returns a list of all police forces available via the API, including their unique identifier and display name. Use this action to retrieve valid force identifiers for use in other actions.

### `List neighbourhoods for a force`
Returns a list of all neighbourhood policing areas for a specified police force. The returned neighbourhood identifiers can be used in subsequent actions to retrieve team members, events, priorities, and boundaries.

### `Get street-level crimes`
Returns crimes recorded at street level within a 1 mile radius of a given latitude and longitude coordinate. Accepts an optional crime category and month filter. Note that returned locations are anonymised approximations, not exact incident locations.

## Obtaining Credentials

No credentials are required. The UK Police API supports anonymous authentication and is open to all users without registration or sign-up.

## Getting Started

1. Add the **Police UK (Independent Publisher)** connector to your flow or app.
2. Create a new connection - no credentials are needed, so this completes immediately.
3. Start with the **List all forces** action to retrieve valid force identifiers, then pass a force identifier into other actions such as **Get street-level crimes** or **List neighbourhoods for a force**.

### Example use cases

- Retrieve street-level crime data for a given postcode coordinate and display it in a canvas app.
- Build an automated monthly report of stop and search activity for a specified force using Power Automate.
- Display neighbourhood policing team contact details within a SharePoint site or Teams tab.
- Surface local crime category trends in a Power BI dashboard using scheduled flow exports.
- Look up the responsible neighbourhood team for any address using the Locate neighbourhood action.

## Known Issues and Limitations

- **Anonymised locations**: All crime and stop and search locations returned by the API are approximate. The Police API deliberately anonymises precise incident locations to protect privacy. Do not use returned coordinates as exact addresses.
- **Scotland coverage**: Scotland is policed by Police Scotland, which is not part of the data.police.uk API. British Transport Police data is included but covers transport infrastructure only, so crime levels for Scotland will appear lower than reality.
- **Monthly data updates**: Crime data is updated monthly, not in real time. Use the **Get last updated date** action to determine the most recent available data period.
- **Rate limiting**: The API uses a leaky bucket algorithm with a limit of 15 requests per second and a burst allowance of 30 requests. Exceeding this returns a 429 Too Many Requests response. Add a Delay action when looping through multiple forces or locations.
- **Data availability**: Not all forces provide data for all operations. Some forces may return empty results for neighbourhood teams, stop and search, or senior officers if they have not published that data to the API.
- **Northern Ireland**: Crime data for Northern Ireland is provided by the Police Service of Northern Ireland (PSNI) and may have different category structures compared to England and Wales forces.