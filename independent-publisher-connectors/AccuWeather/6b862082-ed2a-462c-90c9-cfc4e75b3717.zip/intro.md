# AutoReview

Creates automatic code review for your Power Automate flows. A Review document scores your flow to configurable metrics. A Report returns the flow information and a Diagram file creates a visual representation of the flow.

## Publisher
Power DevBox

## Prerequisites
A Power Automate license and a compliant DLP policy ([Access to Power Automate Management Connectors](https://learn.microsoft.com/en-us/connectors/flowmanagement/) or [Dataverse Connectors](https://learn.microsoft.com/en-us/connectors/commondataserviceforapps/))

## Supported Operations

### Info
Returns latest information on the connector, including version and key links. Find more information on the connector [here](https://powerdevbox.com/connectors.html).

### JSON
Returns the AutoReview review in a json format

### File
Returns a file of either the flow Review, Report, or Diagram

## Obtaining Credentials
A API key is required, available to request [here](https://powerdevbox.com/contact.html)

## Getting Started
Use either 'Get Flow' action or Dataverse 'Get Row by ID' action to return a flows definition/clientData values. Pass these values and other metadata into the AutoReview Connector.

## Known Issues and Limitations
The Dataverse connector requires the definition input to be the clientData inside a json expression `json(outputs('Get_a_row_by_ID')?['body/clientdata'])`

