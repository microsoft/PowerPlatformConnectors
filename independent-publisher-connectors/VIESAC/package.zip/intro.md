# VIESAC — EU VAT Validation

VIESAC validates VAT numbers against official sources and saves audit records with PDF and XML certificates. The connector supports checks for EU member states and Northern Ireland through VIES, Great Britain through HMRC, Norway through Brønnøysundregistrene, and Switzerland through the UID Register.

## Publisher

VIESAC — support@viesac.eu

## Prerequisites

- A [VIESAC account](https://viesac.eu/register).
- An API key from the [VIESAC dashboard](https://viesac.eu/app).

## Supported operations

| Operation | Description |
| --- | --- |
| Create Audit | Validate a VAT number and save an audit record. |
| List Audits | Retrieve audit history using available filters. |
| Get Audit | Retrieve an audit by its reference number. |
| Download PDF Certificate | Download the audit's PDF certificate. |
| Download XML Certificate | Download the audit's XML evidence. |
| Get Account | View the account plan and usage information. |

## Obtaining credentials

Create a VIESAC account, then generate an API key in the dashboard. When creating a connector connection, enter `Bearer ` followed by the key in the API Key field. For example, enter `Bearer vac_your_api_key`. Keep the key private.

## Getting started

Create a connection with your VIESAC API key. Add **Create Audit** to a flow, supply the country code and VAT number, and use the returned audit reference with **Get Audit** or either certificate download operation.

The included **VIESAC validation sample** flow runs **Get Account**, **List Audits**, **Create Audit**, and **Get Audit** in sequence. It validates the example VAT number `DE129274202`, then passes the new audit reference to **Get Audit**. Running the sample creates one audit and uses one request from your account's allowance. Create your own connection after importing the solution; no API key is included in this package.

## Known issues and limitations

- An API key is required for every connection.
- Usage is subject to the limits of the connected VIESAC account.
- Certificate operations require an existing audit reference.
- The availability of a national registry can affect validation results.

## Links

- [Website](https://viesac.eu)
- [API documentation](https://viesac.eu/api-docs)
- [Privacy policy](https://viesac.eu/privacy-policy)
- [Support](mailto:support@viesac.eu)
