# Firmaradar (Independent Publisher)

Firmaradar is an enrichment platform for Norwegian company intelligence. It fuses data from multiple authoritative sources — the Norwegian Business Register (Brønnøysundregistrene), the Norwegian Tax Administration (Skatteetaten) and foreign PEP and sanctions registers — and adds proprietary enrichment on top: distress classification, transparent risk scoring, fuzzy person-matching, group-structure analytics and audit-grade compliance pipelines. This connector exposes 21 operations plus 2 instant triggers you can drop into a flow to enrich — and react to changes in — customers, suppliers, partners and counterparties with structured Norwegian company intelligence.

## Publisher: Lars Kvanum

Stack owner: Firmaradar AS (Norway).

## Prerequisites

1. An active Firmaradar account at https://firmaradar.no.
2. A personal API key issued via **Min side → API-nøkler** (https://firmaradar.no/min-side/api-keys). The key is sent as the `X-API-Key` HTTP header on every request.
3. An active subscription for the operations you intend to use. Some operations require a data-processing agreement (DPA) signed in your Firmaradar account — most notably AML and PEP screening.

The free tier covers a generous slice of company-profile, ownership, roles, financial-history and announcement operations. Compliance-tier operations (AML, audit-grade risk scoring) require a paid plan and explicit DPA acceptance.

## Supported Operations

The connector exposes 21 production operations across 6 functional areas, plus 2 instant (webhook) triggers. Many operations combine several upstream sources behind a single call.

### Company

Look up a full company profile by organization number, expand its ownership tree and board or signatory roles, retrieve multi-year financial history, track recent registry changes, search the company universe and compare two companies side by side.

### Person

Search for a person, resolve the roles a person holds across companies and list the shareholdings a person controls.

### Risk

Retrieve risk signals for a company, search the registry announcements feed, fetch a transparent risk score (0–100) with a component breakdown and run a statutory "foretak i vanskeligheter" (company in difficulty) distress assessment.

### Industry

List companies within a NACE industry code and find companies related to a given company through ownership or roles.

### AML

Screen a person or company against AML and PEP lists and retrieve a combined AML score. These operations are gated behind a signed DPA and are persisted in an audit log.

### Group support

Retrieve an overview of public group-support and grants exposure (Innovasjon Norge / SkatteFUNN) for a company.

### Triggers (instant)

Two webhook-based instant triggers let a flow start the moment something changes, instead of polling:

- **When a company changes** — fires on an announcement, status, ownership or grant change for one organization number.
- **When a company in a NACE industry changes** — fires when any company in a chosen NACE code changes, with event-type, geographic (fylke/kommune/landsdel) and size filters.

Power Automate registers its own callback URL when the flow is created and automatically unsubscribes when it is removed. Both require company monitoring on the account. NACE deliveries are HMAC-signed (`X-Firmaradar-Signature`).

In addition, three documentation aliases are exposed in the spec to give a one-to-one mapping with the Firmaradar MCP-tool catalog; these forward to the same backend as the canonical operations above.

## Obtaining Credentials

1. Sign in to https://firmaradar.no with a verified Firmaradar account.
2. Open **Min side → API-nøkler** (My account → API keys).
3. Click **Generer ny API-nøkkel** (Generate new key) and copy the key. The full key is shown only once — store it in a secrets manager or in your connection settings.
4. When you create a flow that uses this connector, paste the key into the **Firmaradar API key** connection field.

You can revoke or rotate the key from the same page at any time.

## Getting Started

1. Create a connection and paste your Firmaradar API key into the **Firmaradar API key** field.
2. Add a Firmaradar action to your flow — for example **Get company** with an organization number such as `923609016` (Equinor ASA).
3. Use the structured output in downstream steps: post a risk alert to Teams, write a KYC record to Dataverse, or enrich a CRM lead.

## Known Issues and Limitations

- **Norwegian-language responses.** Field labels and human-readable strings in responses are written in Norwegian (bokmål), reflecting the source registries. English summaries are included where practical.
- **Rate limits.** Free-tier accounts are limited to 60 requests per minute. AML operations have a stricter limit of 50 requests per 30 minutes regardless of plan.
- **Audit logging.** Calls to AML and marketplace risk operations are persisted in an audit log for 60 months as required by Norwegian KYC regulations. The `X-FR-Purpose` and `X-FR-DPA-Confirmed` headers must be set on AML calls; missing headers return HTTP 403.
- **Compliance gates.** The `getRiskScore` operation may return HTTP 403 with `error_code=marketplace_hidden` until the account passes the relevant compliance gate. The spec marks this operation with the `x-firmaradar-compliance-gate` extension so clients can hide or disable it dynamically.
- **9-digit organization numbers only.** All `orgnr` path parameters must be exactly 9 digits (Norwegian organization-number format).
- **Opaque pagination cursors.** The `next_cursor` value returned by paginated operations must be passed back verbatim — do not parse or modify it.

## Frequently Asked Questions

### Do I have to be a Norwegian company to use this connector?

No. Non-Norwegian banks, KYC vendors, AML platforms and M&A advisors can call Firmaradar as their canonical Norwegian backend and stitch the result into a wider multi-jurisdiction compliance view.

### Is this just a wrapper around the public business register?

No. Public registry data alone rarely answers a real business question. Firmaradar reconciles multiple sources and layers proprietary signals — person matching, risk modelling, group analytics and compliance plumbing — so a single call returns a decision-ready view.

## Deployment Instructions

After certification, end users do not need to install the connector manually — it becomes available in the standard connector catalog in Power Automate, Power Apps and Logic Apps. Developers who want to deploy before certification can run:

```bash
paconn create --api-prop apiProperties.json \
              --api-def apiDefinition.swagger.json \
              --icon icon.png
```

See https://learn.microsoft.com/en-us/connectors/custom-connectors/paconn-cli for the full CLI reference.

## Support

- **Issues with the connector definition** (Swagger, icon, metadata): file an issue or pull request against https://github.com/microsoft/PowerPlatformConnectors.
- **Issues with the Firmaradar API** (data, rate limits, account access): contact support@firmaradar.no.
- **General Firmaradar documentation:** https://firmaradar.no/api-dokumentasjon.
